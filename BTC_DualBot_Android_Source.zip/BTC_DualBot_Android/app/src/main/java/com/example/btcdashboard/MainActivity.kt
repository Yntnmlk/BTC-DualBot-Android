package com.example.btcdashboard

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var endpoint: EditText
    private lateinit var status: TextView
    private lateinit var demoStatus: TextView
    private lateinit var liveStatus: TextView
    private lateinit var signal: TextView
    private lateinit var refreshButton: Button
    private lateinit var approveBuy: Button
    private lateinit var approveSell: Button
    private lateinit var rejectButton: Button
    private var signalId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(18, 30, 48)
        window.navigationBarColor = Color.rgb(18, 30, 48)
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(24))
            setBackgroundColor(Color.rgb(244, 247, 251))
        }
        scroll.addView(root)
        setContentView(scroll)

        addText("BTCUSD DUAL BOT", 24, Color.rgb(18, 30, 48), true)
        addText("Mobile companion • Exness MT5 • manual live approval", 14, Color.DKGRAY, false)
        addText("Important: MT5 Expert Advisors run on Windows, not inside this Android app. This app is a remote dashboard client.", 14, Color.rgb(140, 65, 0), true)

        card {
            addText("WINDOWS BOT CONNECTION", 17, Color.rgb(18, 30, 48), true)
            endpoint = EditText(this).apply {
                hint = "https://your-secure-bot-server.example"
                setSingleLine(true)
                textSize = 14f
            }
            addView(endpoint, matchWrap())
            addText("Use only a secure HTTPS endpoint configured by you. Do not expose a trading computer directly to the public internet.", 12, Color.DKGRAY, false)
            refreshButton = Button(this@MainActivity).apply {
                text = "CHECK CONNECTION / REFRESH"
                setOnClickListener { refreshStatus() }
            }
            addView(refreshButton, matchWrap())
        }

        card {
            addText("ACCOUNT STATUS", 17, Color.rgb(18, 30, 48), true)
            demoStatus = addText("DEMO: Not connected", 15, Color.DKGRAY, true)
            liveStatus = addText("REAL: Not connected", 15, Color.DKGRAY, true)
            status = addText("No connection yet. Enter your Windows bridge URL.", 13, Color.DKGRAY, false)
        }

        card {
            addText("SIGNAL & APPROVAL", 17, Color.rgb(18, 30, 48), true)
            signal = addText("No pending live signal", 16, Color.DKGRAY, true)
            approveBuy = Button(this@MainActivity).apply {
                text = "APPROVE BUY :)"
                isEnabled = false
                setOnClickListener { approve("BUY") }
            }
            addView(approveBuy, matchWrap())
            approveSell = Button(this@MainActivity).apply {
                text = "APPROVE SELL >:("
                isEnabled = false
                setOnClickListener { approve("SELL") }
            }
            addView(approveSell, matchWrap())
            rejectButton = Button(this@MainActivity).apply {
                text = "REJECT SIGNAL"
                isEnabled = false
                setOnClickListener { reject() }
            }
            addView(rejectButton, matchWrap())
            addText("Approval buttons stay disabled until a compatible Windows bridge returns a fresh pending signal. This starter project does not place trades by itself.", 12, Color.DKGRAY, false)
        }

        card {
            addText("STRATEGY MODULES", 17, Color.rgb(18, 30, 48), true)
            addText("• Demand / supply retests\n• Swing structure and breakout checks\n• Liquidity sweep checks\n• Rule-based score\n• Separate demo / real risk settings\n• Live entries require approval", 14, Color.DKGRAY, false)
        }
    }

    private fun addText(text: String, size: Int, color: Int, bold: Boolean): TextView {
        val v = TextView(this)
        v.text = text
        v.textSize = size.toFloat()
        v.setTextColor(color)
        if (bold) v.setTypeface(null, android.graphics.Typeface.BOLD)
        v.setPadding(0, dp(5), 0, dp(8))
        root.addView(v, matchWrap())
        return v
    }

    private fun card(content: LinearLayout.() -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(Color.WHITE)
            elevation = dp(2).toFloat()
        }
        val params = LinearLayout.LayoutParams(-1, -2)
        params.setMargins(0, dp(10), 0, dp(5))
        root.addView(box, params)
        val old = root
        root = box
        content()
        root = old
    }

    private fun refreshStatus() {
        val base = endpoint.text.toString().trim().trimEnd('/')
        if (!base.startsWith("https://")) {
            status.text = "Use an HTTPS bridge URL. Plain HTTP is blocked by this app."
            return
        }
        status.text = "Checking Windows bot…"
        refreshButton.isEnabled = false
        thread {
            try {
                val response = request("$base/status", "GET", null)
                runOnUiThread {
                    status.text = response
                    // The bridge protocol should return JSON fields demo_status, live_status,
                    // pending_signal_id and signal_summary. This starter client shows raw status.
                    demoStatus.text = "DEMO: See bridge status"
                    liveStatus.text = "REAL: See bridge status"
                    signal.text = "Signal data requires the compatible bridge API."
                    signalId = null
                    setApprovalEnabled(false)
                    refreshButton.isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Connection failed: ${e.message ?: "unknown error"}"
                    refreshButton.isEnabled = true
                }
            }
        }
    }

    private fun approve(side: String) {
        val id = signalId ?: return
        android.app.AlertDialog.Builder(this)
            .setTitle("Confirm real-account order")
            .setMessage("Approve $side for pending signal $id? This can place a real-money trade.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Confirm") { _, _ -> sendDecision("approve", id, side) }
            .show()
    }

    private fun reject() {
        val id = signalId ?: return
        sendDecision("reject", id, "")
    }

    private fun sendDecision(action: String, id: String, side: String) {
        val base = endpoint.text.toString().trim().trimEnd('/')
        thread {
            try {
                val body = """{"signal_id":"$id","action":"$action","side":"$side"}"""
                val response = request("$base/decision", "POST", body)
                runOnUiThread {
                    status.text = response
                    signal.text = "Decision sent. Refresh status to verify result."
                    signalId = null
                    setApprovalEnabled(false)
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Decision failed: ${e.message ?: "unknown error"}" }
            }
        }
    }

    private fun request(urlString: String, method: String, body: String?): String {
        val conn = (URL(urlString).openConnection() as HttpURLConnection)
        conn.requestMethod = method
        conn.connectTimeout = 5000
        conn.readTimeout = 5000
        conn.setRequestProperty("Accept", "application/json")
        if (body != null) {
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: "HTTP $code"
        conn.disconnect()
        if (code !in 200..299) throw IllegalStateException("HTTP $code: $text")
        return text
    }

    private fun setApprovalEnabled(enabled: Boolean) {
        approveBuy.isEnabled = enabled
        approveSell.isEnabled = enabled
        rejectButton.isEnabled = enabled
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
