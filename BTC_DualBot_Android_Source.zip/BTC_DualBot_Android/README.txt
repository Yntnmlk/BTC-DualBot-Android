BTC Dual Bot Android Companion — source project
================================================

This is an Android Studio project, NOT a compiled APK. The current environment does not have Android SDK/build tools installed, so an APK could not be compiled or verified here.

What it is:
- A small Android companion UI for the Windows BTC Dual Bot.
- HTTPS-only connection field.
- Status refresh client.
- Explicit confirmation dialog for any future real-account approval.
- Buy/sell approval buttons are disabled until a compatible bridge provides fresh pending-signal data.

Important:
- This Android app does NOT run the MetaTrader 5 Python package or MT5 Expert Advisor on the phone.
- The existing Windows desktop bot does not yet expose the HTTPS REST bridge endpoints this Android client expects (/status and /decision). Therefore, the client is a starter UI and is NOT connected to trading until that bridge is implemented and secured.
- Do not expose an unauthenticated trading API to the internet. Use authentication, TLS, short-lived signal IDs, expiry checks, rate limits, and preferably a VPN/private network.
- Never enter Exness/MT5 passwords into this app.

Build an APK:
1. Install Android Studio on a computer.
2. Open this folder as an existing project.
3. Let Gradle sync and install the Android SDK for API 35.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK path.

The project uses Android Gradle Plugin 8.7.3 and Kotlin 2.0.21; an internet connection is needed to download Gradle dependencies during the first build.
